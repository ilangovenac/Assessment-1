#Word count - With space before and after sentence
from flask import Flask, request, render_template

app = Flask(_name_)
@app.route('/')

def my_form():
    return render_template('home.html')

@app.route('/',methods=['POST'])
def my_form_post():
    sen=request.form['sen']
    sen=sen.strip()
    count=0
    for x in sen:
        if x==' ':
            count+=1
    final=count+1
    
    return final

if  _name_== "_main_":
    app.run(debug=True)
