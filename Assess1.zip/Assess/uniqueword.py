#Finding unique word 
from flask import Flask, request, render_template

app = Flask(_name_)
@app.route('/')

def my_form():
    return render_template('home.html')

@app.route('/',methods=['POST'])
def my_form_post():
    sen=request.form['sen']
    sen=input('Enter words: ')
    l=sen.split()
    print('Unique words are: ')
    for x in l:
        if x.islower()==True:
            print(x, end=' ')
            return x

if  _name_== "_main_":
    app.run(debug=True)
