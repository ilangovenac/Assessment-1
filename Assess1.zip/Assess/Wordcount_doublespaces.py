#Word count with 2 or more double spaces in sentence
from flask import Flask, request, render_template

app = Flask(_name_)
@app.route('/')

def my_form():
    return render_template('home.html')

@app.route('/',methods=['POST'])
def my_form_post():
    sen=request.form['sen']
    sen=input('Enter a sentence: ')
    sen=sen.strip()
    dcount=0
    i=-1
    while True:
        value=sen.find('  ',i+1,len(sen))
        if value==-1:
            break
        dcount+=1
        i=value
    j=0
    scount=0
    while j<len(sen):
        if sen[j]==' ' and sen[j+1]!=' ':
            scount+=1
        j+=1
    scount-=dcount
    print('No of words',scount+dcount+1)
    final=scount+dcount+1
    return final
    
if  _name_== "_main_":
    app.run(debug=True)