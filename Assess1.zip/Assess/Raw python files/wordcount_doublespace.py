#Word count with 2 or more double spaces in sentence
sen=input('Enter a sentence: ')
sen=sen.strip()
dcount=0
i=-1
while True:
    value=sen.find('  ',i+1,len(sen))
    if value==-1:
        break
    dcount+=1
    i=value
j=0
scount=0
while j<len(sen):
    if sen[j]==' ' and sen[j+1]!=' ':
        scount+=1
    j+=1
scount-=dcount
print('No of words',scount+dcount+1)