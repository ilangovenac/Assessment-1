#Word count - With space before and after sentence

sen=input('Enter a sentence: ')
sen=sen.strip()
count=0
for x in sen:
    if x==' ':
        count+=1
print('Number of words:',count+1)