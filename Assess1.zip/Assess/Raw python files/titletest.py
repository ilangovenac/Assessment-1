#Title test
sen=input('Enter input for Title test: ')
print('Title format:',sen.title())