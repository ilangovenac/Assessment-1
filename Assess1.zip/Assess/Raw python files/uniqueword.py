#Finding unique word 
sen=input('Enter words: ')
l=sen.split()
print('Unique words are: ')
for x in l:
    if x.islower()==True:
        print(x, end=' ')